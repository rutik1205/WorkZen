from scapy.all import *

packets = rdpcap("capture.pcapng")

for packet in packets:

    print("\n--- PACKET ---")

    if packet.haslayer(Ether):
        print("Ethernet")
        print("Source MAC:", packet[Ether].src)
        print("Destination MAC:", packet[Ether].dst)

    if packet.haslayer(IP):
        print("IP")
        print("Source IP:", packet[IP].src)
        print("Destination IP:", packet[IP].dst)

    if packet.haslayer(TCP):
        print("TCP")
        print("Source Port:", packet[TCP].sport)
        print("Destination Port:", packet[TCP].dport)

    elif packet.haslayer(UDP):
        print("UDP")
        print("Source Port:", packet[UDP].sport)
        print("Destination Port:", packet[UDP].dport)